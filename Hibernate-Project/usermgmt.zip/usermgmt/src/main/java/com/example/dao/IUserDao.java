package com.example.dao;
import com.example.model.User;
public interface IUserDao 
{
	void saveUser(User user);

}
