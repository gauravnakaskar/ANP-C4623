package com.example.main;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import com.example.model.User;
import com.example.dao.*;
public class App {
  public static void main(String[] args) 
  {
	 
	 
  }
}

