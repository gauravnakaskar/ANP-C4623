package com.onetoone;
import com.onetoone.entity.*;
import com.onetoone.dao.*;
import java.util.*;
public class App 
{
    public static void main( String[] args )
    { 
    	  Instructor instructor = new Instructor();
    	  InstructorDetail insd=new InstructorDetail();
    	  instructor.setFirstName("abc");
    	  instructor.setLastName("xyz");
    	  instructor.setEmail("a@");	
    	  insd.setYoutubeChannel("y.com");
    	  insd.setHobby("abc");
    	  insd.setInstructor(instructor);
    	  InstructorDao instructorDao = new InstructorDao();
          instructorDao.saveInstructor(instructor);
    	  //instructor.setInstructordetail(insd);
    	  List<Course> courses = new ArrayList<>();
    	  Course tempCourse1 = new Course();
    	  tempCourse1.setTitle("aaaaa..");
    	  tempCourse1.setInstructor(instructor);
    	  courses.add(tempCourse1);
    	  
    	  CourseDao coursedao = new CourseDao();
          coursedao.saveCourse(tempCourse1);
  
         
       
        
         
         
    }
}
