package com.bldmgmt.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import com.bldmgmt.dao.BloodDao;
import com.bldmgmt.model.Blood;

public class App
{
    public static void main(String[] args) {
        BloodDao blddao = new BloodDao();
        
        Transaction transaction = null;
        final SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();

        try (Session session = sessionFactory.openSession()) {
            transaction = session.beginTransaction();

            Blood b = new Blood();
            b.setId(1);
            b.setName("shiv");
            b.setBloodType("O+");
            b.setAge(26);
            
            Blood b1 = new Blood();
            b1.setId(2);
            b1.setName("Raj");
            b1.setBloodType("A+");
            b1.setAge(62);

            blddao.saveBlood(b);
            System.out.println("Saved successfully");

            //update
            b.setAge(46);
            blddao.updateBlood(b);
            System.out.println("Updated Successfully");

           
            blddao.deleteBlood(b1);
            System.out.println("deleted successfully!");

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }
}
