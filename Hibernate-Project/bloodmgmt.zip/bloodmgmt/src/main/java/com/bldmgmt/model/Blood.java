package com.bldmgmt.model;

import javax.persistence.*;
import lombok.*;
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="blood")

public class Blood 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	@Column(name = "id")
	private int id;
	
	@Column(name = "name")
	private String name;
	
	@Column(name = "BloodType")
    private String bloodType;
	
	@Column(name = "Age")
    private int age;
	
}
