package com.bldmgmt.dao;

import com.bldmgmt.model.*;

public interface IBloodDao 
{
	void saveBlood(Blood bld);
    
    void updateBlood(Blood bld);
    
    void deleteBlood(Blood bld);

}
